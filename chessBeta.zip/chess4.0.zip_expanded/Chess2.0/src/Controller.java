import javax.swing.JButton ;
import java.awt.event.*;
import javax.swing.Timer ;


public class Controller implements ActionListener {
	protected Model model;
	public Timer time;
	protected int seconds,minutes;
	protected boolean tourJeu=true; //quand vrai pi�ce blanche qui joue
	
	//On initalise la selection d'une pi�ce � faux
    public Controller(Model p){
        this.model= p;
        minutes=2;
        seconds=30;
   	 	timer();
  	  	time.start();
        p.selection = false;
    }
	
    public void swapIcone() {
		model.caseApres.setIcon(model.caseAvant.getIcon());
        model.caseAvant.setIcon(null);
	}
    
    public void selectionPiece(ActionEvent e) {
    	 
    	if (model.selection==false){
    		model.caseAvant= (JButton) e.getSource();
    		model.xAvant=model.caseAvant.getX()/98;
    		model.yAvant=model.caseAvant.getY()/94;
    		
    		//verifie si la case n'est pas vides
    		if(model.echequier[model.xAvant][model.yAvant]!=null && model.echequier[model.xAvant][model.yAvant].couleur && tourJeu ){
                 model.selection = true;
                 //System.out.println("x="+model.xAvant+" y="+model.yAvant+" "+model.echequier[model.xAvant][model.yAvant].nom);
    		 }
    		else {
    			System.out.println("Case vide " + model.xAvant + " " + model.yAvant);
    			}
    	}
    	else if (model.selection==true) {
    		model.caseApres= (JButton) e.getSource();
    		model.xApres=model.caseApres.getX()/98;
    		model.yApres=model.caseApres.getY()/94;
    		if (!model.obstacle()) {
    			//System.out.println(model.xApres+" "+model.yApres);
    			
    			if(model.Victoire(model.xApres,model.yApres))
        			System.exit(0);
    			//model.promotion(model.xAvant, model.yApres);
    			model.misAJour();
        		swapIcone();
        		model.promotion(model.xApres,model.yApres);
        		tourJeu= !tourJeu;
    		}
    		
    		model.selection = false;
		}
    		//calNbP();
	}

    public void botjoue() {
    	int random;
    	if(!tourJeu) {
    		model.monBot.intelligent(model.echequier);
    		
    		model.xApres=model.monBot.jouerx;
    		model.yApres=model.monBot.jouery;
    		
    		model.caseAvant=model.mesboutons[model.monBot.pieceChoisis.getX()][model.monBot.pieceChoisis.getY()];
    		model.caseApres=model.mesboutons[model.xApres][model.yApres]; 
    		//Prend une piece random
    		/*while(model.monBot.malistex.size()==0) {
	    		random = (int)(Math.random()* model.monBot.mespieces.size()-1);
	    		model.xAvant=model.monBot.mespieces.get(random).getX();
	    		model.yAvant=model.monBot.mespieces.get(random).getY();
	    		//System.out.println("x="+model.xAvant+" y="+model.yAvant);
		    	System.out.println("Le bot choisis:="+model.monBot.mespieces.get(random).nom);
	    		model.monBot.deplacement(model.monBot.mespieces.get(random), model.echequier);
    		}
    		//une fois que la piece est choisis joue
    		
    		random = (int)(Math.random()* model.monBot.malistex.size()-1);
    		model.xApres=model.monBot.malistex.get(random);
    		model.yApres=model.monBot.malistey.get(random);
    		model.caseAvant=model.mesboutons[model.xAvant][model.yAvant];
    		model.caseApres=model.mesboutons[model.xApres][model.yApres]; 
    		*/
    		//System.out.println("bot destination:x "+model.xApres+" y "+model.yApres+" random:"+random);
    		if(model.Victoire(model.xApres,model.yApres))
    			System.exit(0);
    		model.misAJour();
    		swapIcone();
    		//model.monBot.malistex.clear();
    		//model.monBot.malistey.clear();
    		model.promotion(model.xApres,model.yApres);
    		
    		tourJeu= !tourJeu;
    		
    	}
    }
    
    @Override
	public void actionPerformed(ActionEvent e) {
    	
    	selectionPiece(e);
    	botjoue();
    }
    
    public int calNbP()
    {
    	int nb = 0;
    	 for (int x = 0; x < 7; x++) {
            
             for (int y = 0; y < 8; y++) {
                 if(model.echequier[y][x] != null && !model.echequier[y][x].couleur) {
                     
                        nb=nb+1;
                        }  
             } 
         }
    	 System.out.println(nb);
    	 return nb;
     }
    	
    
    
    public void timer() {
    	time = new Timer(1000,new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				seconds--;
				if(seconds==-1)
				{
					seconds=59;
					minutes--;
				}
				if(minutes==0 && seconds == 0)
					System.exit(1);
				
				System.out.println(minutes+":"+seconds);
			}
    		
    	});
    }
}	      

