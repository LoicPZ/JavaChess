import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import pi�ce.*;
import java.util.ArrayList;

public class Model implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//�ch�quier
	public Piece[][] echequier;
	public Controller controller;
	public int xAvant, xApres, yAvant, yApres;
	public boolean selection;
	public JButton caseAvant, caseApres;
	public int timer = 100;
	public Bot monBot = new Bot();
	public JButton[][] mesboutons;
	public ArrayList<Integer> listex = new ArrayList<Integer>(); 
	public ArrayList<Integer> listey = new ArrayList<Integer>(); 
	//constructeur
	public Model() {
		this.echequier = new Piece[8][7];
		
		initialiserEchequier();
	}
	//initialiser le tableau
	public void initialiserEchequier(){
		 for (int y=0; y<7; y++){
            
        	for (int x=0; x<8; x++){
        		
                if ((y==1) || (y==5)) {
                    this.echequier[x][y] = new Pion(x, y);
                	if (y==1)
                		this.monBot.mespieces.add(this.echequier[x][y]);
                	else
                		this.monBot.pieceAdverse.add(this.echequier[x][y]);
                }
                if ((y==0) || (y==6)){
                	
                    if ((x==0) || (x==7)) {
                        this.echequier[x][y] = new Tour(x, y);
	                    if (y==0)
	                    	this.monBot.mespieces.add(this.echequier[x][y]);
	                    else
	                		this.monBot.pieceAdverse.add(this.echequier[x][y]);
                    }
                    if ((x==1) || (x==6)) {
                        this.echequier[x][y] = new Cavalier(x, y);
                         if (y==0)
                        	 this.monBot.mespieces.add(this.echequier[x][y]);
                         else
                     		this.monBot.pieceAdverse.add(this.echequier[x][y]);
                    }
                    if ((x==2) || (x==5)) {
                        this.echequier[x][y] = new Fou(x, y);
                        if (y==0)
                        	this.monBot.mespieces.add(this.echequier[x][y]);
                        else
                    		this.monBot.pieceAdverse.add(this.echequier[x][y]);
                    }
                    if (x==3) {
                        this.echequier[x][y] = new Reine(x, y);
                        if (y==0)
                        	this.monBot.mespieces.add(this.echequier[x][y]);
                        else
                    		this.monBot.pieceAdverse.add(this.echequier[x][y]);
                    }
                    if (x==4) {
                        this.echequier[x][y] = new Roi(x, y);
                        if (y==0)
                        	this.monBot.mespieces.add(this.echequier[x][y]);
                        else
                    		this.monBot.pieceAdverse.add(this.echequier[x][y]);
                    }
                }
            }
        }
    }
	//mettre a jour la view avec le mouvement
	public void misAJour(){
		//supprime une piece de la liste de piece du bot
		if(this.echequier[this.xApres][this.yApres]!=null && !this.echequier[this.xApres][this.yApres].couleur)
			for (Piece i : monBot.mespieces) {
				if(i.getX()==this.echequier[this.xApres][this.yApres].getX() && i.getY()==this.echequier[this.xApres][this.yApres].getY() ) {
					monBot.mespieces.remove(i);
					break;
				}
			}
		//�change les positions
	    this.echequier[this.xApres][this.yApres] = this.echequier[this.xAvant][this.yAvant];
	    this.echequier[this.xAvant][this.yAvant] = null;
	    this.echequier[this.xApres][this.yApres].setX(this.xApres);
	    this.echequier[this.xApres][this.yApres].setY(this.yApres);
	}
	//
	protected boolean obstacle()
    {
        int a = this.xApres - this.xAvant;
        int b = this.yApres - this.yAvant;
        listex.clear();
        listey.clear();
        //condition si pi�ce est un pion
        System.out.println(xAvant+" "+yAvant);
        /*if(this.echequier[this.xAvant][this.yAvant].nom=="Roi"){
        		for (Piece i : monBot.mespieces) {
        			System.out.println(i);
        		}
        }*/
        if(this.echequier[this.xAvant][this.yAvant].nom=="Pion") {
        	if(this.echequier[this.xAvant][this.yAvant].couleur) {
        		//
        		if (a<0 && this.echequier[this.xAvant-1][this.yAvant-1]!=null){
        			return !this.echequier[this.xAvant][this.yAvant].attack(xApres,yApres,1);
        		}
        		//
        		else if ( a>0 && this.echequier[this.xAvant+1][this.yAvant-1]!=null){
        			return !this.echequier[this.xAvant][this.yAvant].attack(xApres,yApres,2);
        		}
        		else if(a==0 && this.echequier[this.xAvant+a][this.yAvant+b]==null) {
        			return !this.echequier[this.xAvant][this.yAvant].move(xApres, yApres);
        		}
        	}
        	else if (!this.echequier[this.xAvant][this.yAvant].couleur) {
        		if (a<0 && this.echequier[this.xAvant-1][this.yAvant+1]!=null){
        			return !this.echequier[this.xAvant][this.yAvant].attack(xApres,yApres,1);
        		}
        		else if (a>0 && this.echequier[this.xAvant+1][this.yAvant+1]!=null){
        			return !this.echequier[this.xAvant][this.yAvant].attack(xApres,yApres,2);
        		}
        		else if( a==0 && this.echequier[this.xAvant+a][this.yAvant+b]==null) {
        			return !this.echequier[this.xAvant][this.yAvant].move(xApres, yApres);
        		}
        	}
        	return true;
        }
        //v�rifie si le mouvement est possible
        if (!this.echequier[this.xAvant][this.yAvant].move(xApres,yApres)){
        	return true;
        }
        //condition cavalier
        if(this.echequier[this.xAvant][this.yAvant].nom=="Cavalier" && (this.echequier[this.xApres][this.yApres]==null || !this.echequier[this.xApres][this.yApres].couleur)) {
        	return false;
        }
      
        //condition g�n�ral v�rifie si aucune pi�ce ne bloque le passsage
        while(a!=0 || b!=0) {
        	if (this.echequier[this.xAvant+a][this.yAvant+b]!=null && this.echequier[this.xAvant][this.yAvant].couleur==this.echequier[this.xAvant+a][this.yAvant+b].couleur)
        		return true;
        	listex.add(xAvant+a);	
    		listey.add(yAvant+b);
    		
        	if(a<0)
        		a++;
        	else if (a>0)
        		a--;
        	if(b<0)
        		b++;
        	else if (b>0)
        		b--;
        	if(a!=0 && b!=0 && this.echequier[this.xAvant+a][this.yAvant+b]!=null)
        		return true;
        	
        }
        return false;
    }
	
	//ferme la fenetre lorsque le roi est mange
	public boolean Victoire(int xAp,int yAp)
    {
    	if(this.echequier[xAp][yAp]!=null && this.echequier[xAp][yAp].nom=="Roi")
    		return true;
    	return false;
    }
    //lorsque le pion esr arrive a la fin on change de type 
    public void promotion(int x,int y)
    {
    	if ( y==0 && this.echequier[x][y].nom=="Pion")
    	{
    		this.echequier[x][y] = new Reine(x,y);
    		echequier[x][y].couleur=true;
    		echequier[x][y].imageload();
    		this.caseAvant.setIcon(null);
    		this.caseApres.setIcon(new ImageIcon(this.echequier[x][y].getImage()));
    		
    		
    	}
    	if ( y==6 && echequier[x][y].nom=="Pion") {
			for (Piece i : monBot.mespieces) {
				if(i.getX()==this.echequier[x][y].getX() && i.getY()==this.echequier[x][y].getY() ) {
					monBot.mespieces.remove(i);
					break;
				}
			}
    		echequier[x][y] = new Reine(x,y);
    		echequier[x][y].couleur=false;
    		echequier[x][y].imageload();
    		monBot.mespieces.add(echequier[x][y]);
    		this.caseAvant.setIcon(null);
    		this.caseApres.setIcon(new ImageIcon(this.echequier[x][y].getImage()));
    	}
    }
    //
}

