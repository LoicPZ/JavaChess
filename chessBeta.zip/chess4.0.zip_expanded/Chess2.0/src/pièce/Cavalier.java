package pi�ce;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Cavalier extends Piece{

	public Cavalier(int x, int y) {
		super(x, y);
		this.nom="Cavalier";
		this.score=50;
		//chargement image
		File input;
		try
		{
			if(this.couleur) input = new File("images/Cavalier_Blanc.png");
			else input = new File("images/Cavalier_Noir.png");
			this.type = ImageIO.read(input);
		} 

		catch(IOException e) 
		{
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	
	public boolean move(int x, int y) {
		if((this.x+1==x && (this.y-2== y || (this.y+2==y)) || 
		(this.x+2==x && (this.y-1==y || this.y+1==y)) ||
		(this.x-1 == x && (this.y-2==y || this.y+2 == y )) ||
		(this.x-2 == x && (this.y-1==y || this.y+1==y))))
			return true;
			
		 
		return false;
	}

	@Override
	public boolean attack(int xApres, int yApres, int i) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void imageload() {
		// TODO Auto-generated method stub
		
	}
}
