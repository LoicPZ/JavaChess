package pi�ce;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Pion extends Piece{
	//constructeur
	public Pion(int x, int y) {
		super(x, y);
		this.nom="Pion";
		this.score=10;
		//chargement image
		File input;
		try
		{
			if(this.couleur) input = new File("images/Pion_Blanc.png");
			else input = new File("images/Pion_Noir.png");
			this.type = ImageIO.read(input);
		} 

		catch(IOException e) 
		{
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	//m�thode de d�placement retourne vrai si d�placement correct, donner en param�tre la destination
	public boolean move(int x,int y) {
		if(this.couleur)//si blanc
		{
			
			if(this.y-1==y && this.x==x) {
				return true;}
		}else 
			if(this.y+1==y && this.x==x)
				return true;
		return false;
	}
	
	public boolean attack(int x,int y, int i) {
		if(this.couleur)//si blanc
		{
			//gauche
			if (i==1) {
				if(this.y-1==y && this.x-1==x) {
					//System.out.println("ici");
					return true;}
			}
			//droite
			if (i==2) {
				if(this.y-1==y && this.x+1==x) {
					//System.out.println("ici");
					return true;}
			}
		}else 
			//gauche
			if (i==1) {
				if(this.y+1==y && this.x-1==x) {
					//System.out.println("ici");
					return true;}
			}
			//droite
			if (i==2) {
				if(this.y+1==y && this.x+1==x) {
					//System.out.println("ici");
					return true;}
			}
		return false;
	}
	@Override
	public void imageload() {
		// TODO Auto-generated method stub
		
	}
}
