package pi�ce;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Tour extends Piece{

	public Tour(int x, int y) {
		super(x, y);
		this.nom="Tour";
		this.score=50;
		//chargement image
		File input;
		try
		{
			if(this.couleur) input = new File("images/Tour_Blanc.png");
			else input = new File("images/Tour_Noir.png");
			this.type = ImageIO.read(input);
		} 

		catch(IOException e) 
		{
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	//m�thode de d�placement
	public boolean move(int x, int y) {
		int a =this.x - x;
		int b = this.y -y;
		if((this.x+a==x && (this.y== y)|| 
				(this.x-a==x && (this.y==y)) ||
				(this.x == x && (this.y+b==y)) ||
				(this.x==x && (this.y-b == y))))
					return true;

		return false;
	}
	@Override
	public boolean attack(int xApres, int yApres, int i) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void imageload() {
		// TODO Auto-generated method stub
		
	}

}
