package pi�ce;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Reine extends Piece {

	public Reine(int x, int y) {
		super(x, y);
		this.nom="Reine";
		this.score=100;
		//chargement image
		File input;
		try
		{
			if(this.couleur) input = new File("images/Reine_Blanc.png");
			else input = new File("images/Reine_Noir.png");
			this.type = ImageIO.read(input);
		} 

		catch(IOException e) 
		{
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	
	public boolean move(int x, int y) {
		int a =this.x - x;
		int b = this.y -y;
		if(
			(this.x==x+a && (this.y== y)|| 
			(this.x==x-a && (this.y==y)) ||
			(this.x == x && (this.y==y+b)) ||
			(this.x==x && (this.y == y-b)) ||
			(this.x== x+a && ((this.y==y+b) || this.y == y-b))||
			(this.x == x-a && ((this.y==y+b) || this.y == y-b)))
			)
					return true;

		return false;
	}
	
	

	@Override
	public boolean attack(int xApres, int yApres, int i) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void imageload() {
		File input;
		try
		{
			if(this.couleur) input = new File("images/Reine_Blanc.png");
			else input = new File("images/Reine_Noir.png");
			this.type = ImageIO.read(input);
		} 

		catch(IOException e) 
		{
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
	}
}
