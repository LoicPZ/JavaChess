package pi�ce;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Fou extends Piece {

	public Fou(int x, int y) {
		super(x, y);
		this.nom="Fou";
		this.score=50;
		//chargement image
		File input;
		try
		{
			if(this.couleur) input = new File("images/Fou_Blanc.png");
			else input = new File("images/Fou_Noir.png");
			this.type = ImageIO.read(input);
		} 

		catch(IOException e) 
		{
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
	}
	public boolean move(int x, int y){
		for(int i=-7; i<7; i++)
			if(((this.x+i==x) && (this.y+i==y)) || ((this.x+i==x) && (this.y-i==y)))
				return true;
		return false;
	}
	@Override
	public boolean attack(int xApres, int yApres, int i) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public void imageload() {
		// TODO Auto-generated method stub
		
	}
}
