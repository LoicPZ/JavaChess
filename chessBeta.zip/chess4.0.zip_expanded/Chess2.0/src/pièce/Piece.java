package pi�ce;
import java.awt.Image;
import java.util.ArrayList;

public abstract class Piece{
	protected int x,y;
	public String nom;
	public boolean couleur; //true=blanc
	protected Image type;
	public int score;
	public ArrayList<Integer> malistex;
	public ArrayList<Integer> malistey;
	//constructeur
	public Piece(int x, int y) {
		this.nom="Vide";
		malistex = new ArrayList<Integer>();
		malistey = new ArrayList<Integer>();
		this.x = x;
		this.y = y;
		
		if(y == 5 || y == 6) this.couleur = true;
		else if (y == 0 || y == 1) this.couleur = false;
	}
	
	//setter/getter
	public Image getImage() {
		return this.type;
	}
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
	}
	public boolean getColor() {
		return couleur;
	}
	public abstract void imageload();
	//fonction mouvement
	public abstract boolean move(int x, int y);
	public abstract boolean attack(int xApres, int yApres, int i);
}
