import java.util.ArrayList;
import pi�ce.*;


public class Bot {
	//public Model 
	public Controller controller;
	public ArrayList<Piece> mespieces;
	public ArrayList<Piece> pieceAdverse;
	//public ArrayList<Integer> malistex;
	//public ArrayList<Integer> malistey;
	public ArrayList<Piece> listeCoup;
	Piece pieceChoisis;
	int jouerx,jouery;
	/*class Node{
		Piece[][] echequierVirtuel;
		int score;
		ArrayList<Node> children;
	}*/
	
	
	public Bot()
	{
		mespieces = new  ArrayList<Piece>(); //liste piece noire
		pieceAdverse = new  ArrayList<Piece>(); //liste piece blanche
		//malistex = new ArrayList<Integer>();//liste coup x
		//malistey = new ArrayList<Integer>();//liste coup y
		listeCoup = new ArrayList<Piece>();
	}
	
	public void intelligent(Piece[][] echequier){
		deplacement(echequier[3][0],echequier);
		
		System.out.println(minmax(echequier,3,false));
		System.out.println(pieceChoisis.nom);
		
	}
	
	
	//fonction test
	protected int minmax(Piece[][] echequier,int profondeur, boolean couleur) {
		int valeurmax=0;
		//si profondeur est 0
		if (profondeur==0) {
			return calculScore(echequier);
		}
		//Joueur noire
		if (couleur==false) {
			valeurmax=-10000;
			//chaque piece
			for (int i=0; i<mespieces.size();i++) {
				deplacement(mespieces.get(i),echequier);
				for (int j=0; j<mespieces.get(i).malistex.size();j++) {	
					int x=mespieces.get(i).getX();
					int y=mespieces.get(i).getY();
					
					//afficher(echequier);
					//
					echequier[mespieces.get(i).malistex.get(j)][mespieces.get(i).malistey.get(j)]=echequier[mespieces.get(i).getX()][mespieces.get(i).getY()];
					echequier[mespieces.get(i).getX()][mespieces.get(i).getY()]=null;
					mespieces.get(i).setX(mespieces.get(i).malistex.get(j));
					mespieces.get(i).setY(mespieces.get(i).malistey.get(j));
					//
					//System.out.println("Joue "+mespieces.get(i).getY()+" "+mespieces.get(i).malistey.get(j));
					//afficher(echequier);
					int val=minmax(echequier,profondeur-1,true);
					
					//d�fait le coup
					//System.out.println("avant");
					//afficher(echequier);
					echequier[x][y]=echequier[mespieces.get(i).getX()][mespieces.get(i).getY()];
					echequier[mespieces.get(i).getX()][mespieces.get(i).getY()]=null;
					
					
					
					if(valeurmax<val) {
						jouerx=mespieces.get(i).getX();
						jouery=mespieces.get(i).getY();
					}
					//System.out.println("Apres");
					//afficher(echequier);
					echequier[x][y].setX(x);
					echequier[x][y].setY(y);
					if(valeurmax<val) {
						valeurmax=val;
						pieceChoisis=echequier[x][y];
					}
					return 0;
				}
			}
		}
		//joueur blanc
		else {
			valeurmax=10000;
			//
			for (int i=0; i<pieceAdverse.size();i++) {
				deplacement(pieceAdverse.get(i),echequier);
				//chaque deplacement
				//if (pieceAdverse.get(i).malistex==null)
				//	continue;
				for (int j=0; j<pieceAdverse.get(i).malistex.size();j++) {
				
					int x=pieceAdverse.get(i).getX();
					int y=pieceAdverse.get(i).getY();
					
					echequier[pieceAdverse.get(i).malistex.get(j)][pieceAdverse.get(i).malistey.get(j)]=echequier[pieceAdverse.get(i).getX()][pieceAdverse.get(i).getY()];
					echequier[pieceAdverse.get(i).getX()][pieceAdverse.get(i).getY()]=null;
					pieceAdverse.get(i).setX(pieceAdverse.get(i).malistex.get(j));
					pieceAdverse.get(i).setY(pieceAdverse.get(i).malistey.get(j));
					//System.out.println("tour des Blanc");
					//afficher(echequier);
					//appel r�cursif
					int val=minmax(echequier,profondeur-1,!couleur);
					//
					if(valeurmax>val) {
						valeurmax=val;
					}
					//d�fait le coup
					
					echequier[x][y]=echequier[pieceAdverse.get(i).getX()][pieceAdverse.get(i).getY()];
					echequier[pieceAdverse.get(i).getX()][pieceAdverse.get(i).getY()]=null;
					echequier[x][y].setX(x);
					echequier[x][y].setY(y);
				}
			}
		}
		
		return valeurmax;
	}

	//permet d'afficher le tableau et l'emplacment des pi�ces
	public void afficher(Piece[][] plateau){
		System.out.print("\n");
		for (int y = 0; y < 7; y++) {
            System.out.print("|");
            for (int x = 0; x < 8; x++) {
                if(plateau[x][y] == null) System.out.print("  |");
                    else{
                        if(plateau[x][y].nom == "Pion" && plateau[x][y].couleur == false) System.out.print("Pn|");
                        if(plateau[x][y].nom == "Pion" && plateau[x][y].couleur == true) System.out.print("Pb|");

                        if(plateau[x][y].nom == "Tour" && plateau[x][y].couleur == false) System.out.print("Tn|");
                        if(plateau[x][y].nom == "Tour" && plateau[x][y].couleur == true) System.out.print("Tb|");

                        if(plateau[x][y].nom == "Cavalier" && plateau[x][y].couleur == false) System.out.print("Cn|");
                        if(plateau[x][y].nom == "Cavalier" && plateau[x][y].couleur == true) System.out.print("Cb|");

                        if(plateau[x][y].nom == "Fou" && plateau[x][y].couleur == false) System.out.print("Fn|");
                        if(plateau[x][y].nom == "Fou" && plateau[x][y].couleur == true) System.out.print("Fb|");

                        if(plateau[x][y].nom == "Roi" && plateau[x][y].couleur == false) System.out.print("Rn|");
                        if(plateau[x][y].nom == "Roi" && plateau[x][y].couleur == true) System.out.print("Rb|");

                        if(plateau[x][y].nom == "Reine" && plateau[x][y].couleur == false) System.out.print("Qn|");
                        if(plateau[x][y].nom == "Reine" && plateau[x][y].couleur == true) System.out.print("Qb|");
                    }
            }
            System.out.println();
        }
		System.out.print("\n");
    }
	
	protected void scanEchequier(Piece[][] echequier) {
		pieceAdverse.clear();
		mespieces.clear();
		for (int x=0; x<8;x++) {
			for (int y=0; y<7;y++) {
				if(echequier[x][y]!=null && echequier[x][y].couleur) {
					pieceAdverse.add(echequier[x][y]);
				}
				if(echequier[x][y]!=null && !echequier[x][y].couleur) {
					mespieces.add(echequier[x][y]);
				}
			}
		}
	}
	
	//Work
	protected int calculScore(Piece[][] echequier) {
		int score=0;
		for(int x=0; x<8;x++) {
			for (int y=0; y<7;y++) {
				if (echequier[x][y]!=null) {
					if (echequier[x][y].couleur)
						score-=echequier[x][y].score;
					else
						score+=echequier[x][y].score;
				}
						
			}
		}
		return score;
	}
	
	public void deplacement(Piece mapiece, Piece[][] echequier){
		if (mapiece.nom=="Pion")
			deplacementPion(mapiece,echequier);
		else if (mapiece.nom=="Cavalier")
			deplacementCavalier(mapiece,echequier);
		else if (mapiece.nom=="Tour")
			deplacementTour(mapiece,echequier);
		else if (mapiece.nom=="Fou")
			deplacementFou(mapiece,echequier);
		else if (mapiece.nom=="Reine")
			deplacementReine(mapiece,echequier);
		else if(mapiece.nom=="Roi")
			deplacementRoi(mapiece,echequier);
	}
	
	protected void deplacementTour(Piece mapiece, Piece[][] echequier) {
		mapiece.malistex.clear();
		mapiece.malistey.clear();
		//deplacement bas
		for (int i = mapiece.getY()+1; i<7; i++) 
		{
			
			if(echequier[mapiece.getX()][i]==null) 
			{
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
			}
			
			else if (echequier[mapiece.getX()][i].couleur!=mapiece.couleur) 
			{
				
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
				break;
			}
			
			else 
			{
			
				break;
			}
		}
		//
		//deplacement haut
		for (int i = mapiece.getY()-1; i>=0; i--) 
		{
			
			if (echequier[mapiece.getX()][i]==null) 
			{
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
			}
			
			else if (echequier[mapiece.getX()][i].couleur!=mapiece.couleur) 
			{ 
				
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
				break;
			}
			
			else 
			{
				
				break;
			} 
		}
		
		//deplacement gauche
		for (int i = mapiece.getX()+1; i<8; i++) 
		{
			
			if(echequier[i][mapiece.getY()]==null) 
			{
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
			}
			
			else if(echequier[i][mapiece.getY()].couleur!=mapiece.couleur)
			{
			
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
				break;
			}
			
			else 
			{
				break;
			} 
		}
		
		//deplacement droite
		for (int i = mapiece.getX()-1; i>=0; i--) {
			
			if(echequier[i][mapiece.getY()]==null) {
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
			}
			
			else if(echequier[i][mapiece.getY()].couleur!=mapiece.couleur) {
			
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
				break;
			}
			
			else {
				break;
			} 
		}
	}

	protected void deplacementFou(Piece mapiece, Piece[][] echequier) {
		if(mapiece.malistex!=null) {
			mapiece.malistex.clear();
			mapiece.malistey.clear();
		}
		int x=mapiece.getX();
		int y=mapiece.getY();
		//deplacement haut gauche
		while(y>0 && x>0) {
			x--;
			y--;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
		//deplacement haut droite
		x=mapiece.getX();
		y=mapiece.getY();
		while(y>0 && x<7) {
			x++;
			y--;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
		//deplacement bas droite
		x=mapiece.getX();
		y=mapiece.getY();
		while(y<6 && x<7) {
			x++;
			y++;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
		//deplacement bas gauche
		x=mapiece.getX();
		y=mapiece.getY();
		while(y<6 && x>0) {
			x--;
			y++;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
	}
	
	protected void deplacementReine(Piece mapiece, Piece[][] echequier) {
		if(mapiece.malistex!=null) {
			mapiece.malistex.clear();
			mapiece.malistey.clear();
		}
		int x=mapiece.getX();
		int y=mapiece.getY();
		//deplacement bas
		for (int i = mapiece.getY()+1; i<7; i++) 
		{
			
			if(echequier[mapiece.getX()][i]==null) 
			{
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
			}
			
			else if (echequier[mapiece.getX()][i].couleur!=mapiece.couleur) 
			{
				
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
				break;
			}
			
			else 
			{
			
				break;
			}
		}
		//
		//deplacement haut
		for (int i = mapiece.getY()-1; i>=0; i--) 
		{
			
			if (echequier[mapiece.getX()][i]==null) 
			{
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
			}
			
			else if (echequier[mapiece.getX()][i].couleur!=mapiece.couleur) 
			{ 
				
				mapiece.malistey.add(i);
				mapiece.malistex.add(mapiece.getX());
				break;
			}
			
			else 
			{
				
				break;
			} 
		}
		
		//deplacement gauche
		for (int i = mapiece.getX()+1; i<8; i++) 
		{
			
			if(echequier[i][mapiece.getY()]==null) 
			{
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
			}
			
			else if(echequier[i][mapiece.getY()].couleur!=mapiece.couleur)
			{
			
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
				break;
			}
			
			else 
			{
				break;
			} 
		}
		
		//deplacement droite
		for (int i = mapiece.getX()-1; i>=0; i--) {
			
			if(echequier[i][mapiece.getY()]==null) {
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
			}
			
			else if(echequier[i][mapiece.getY()].couleur!=mapiece.couleur) {
			
				mapiece.malistey.add(mapiece.getY());
				mapiece.malistex.add(i);
				break;
			}
			
			else {
				break;
			} 
		}
		//deplacement haut gauche
		while(y>0 && x>0) {
			x--;
			y--;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
		//deplacement haut droite
		x=mapiece.getX();
		y=mapiece.getY();
		while(y>0 && x<7) {
			x++;
			y--;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
		//deplacement bas droite
		x=mapiece.getX();
		y=mapiece.getY();
		while(y<6 && x<7) {
			x++;
			y++;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
		//deplacement bas gauche
		x=mapiece.getX();
		y=mapiece.getY();
		while(y<6 && x>0) {
			x--;
			y++;
			if (echequier[x][y]==null) {
				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
			}
			else if(echequier[x][y].couleur!=mapiece.couleur) 
			{

				mapiece.malistex.add(x);
				mapiece.malistey.add(y);
				break;
			}
			else break;		
		}
	}
	//ne fonctionne que pour les noirs
	protected void deplacementPion(Piece mapiece, Piece[][] echequier) {
		if(mapiece.malistex!=null) {
			mapiece.malistex.clear();
			mapiece.malistey.clear();
		}
		if (!mapiece.couleur) {
			if (mapiece.getY()<6 && echequier[mapiece.getX()][mapiece.getY()+1]==null) {
				mapiece.malistey.add(mapiece.getY()+1);
				mapiece.malistex.add(mapiece.getX());
			}
			if (mapiece.getY()<6 && mapiece.getX()>0 && echequier[mapiece.getX()-1][mapiece.getY()+1]!=null && echequier[mapiece.getX()-1][mapiece.getY()+1].couleur!=mapiece.couleur ) {
				mapiece.malistey.add(mapiece.getY()+1);
				mapiece.malistex.add(mapiece.getX()-1);
			}
			if (mapiece.getY()<6 && mapiece.getX()<7 && echequier[mapiece.getX()+1][mapiece.getY()+1]!=null && echequier[mapiece.getX()+1][mapiece.getY()+1].couleur!=mapiece.couleur ) {
				mapiece.malistey.add(mapiece.getY()+1);
				mapiece.malistex.add(mapiece.getX()+1);
			}
		}
		else {
			if (mapiece.getY()>0 && echequier[mapiece.getX()][mapiece.getY()-1]==null) {
				mapiece.malistey.add(mapiece.getY()-1);
				mapiece.malistex.add(mapiece.getX());
			}
			if (mapiece.getY()>0 && mapiece.getX()>0 && echequier[mapiece.getX()-1][mapiece.getY()-1]!=null && echequier[mapiece.getX()-1][mapiece.getY()-1].couleur!=mapiece.couleur ) {
				mapiece.malistey.add(mapiece.getY()-1);
				mapiece.malistex.add(mapiece.getX()-1);
			}
			if (mapiece.getY()>0 && mapiece.getX()<7 && echequier[mapiece.getX()+1][mapiece.getY()-1]!=null && echequier[mapiece.getX()+1][mapiece.getY()-1].couleur!=mapiece.couleur ) {
				mapiece.malistey.add(mapiece.getY()-1);
				mapiece.malistex.add(mapiece.getX()+1);
			}
		}
			
		//System.out.println(mapiece.getX()+" "+mapiece.getY());
	}
	
	protected void deplacementCavalier(Piece mapiece, Piece[][] echequier){
		mapiece.malistex.clear();
		mapiece.malistey.clear();
		//bas droite droite
		if(mapiece.getX()<=5 && mapiece.getY()<=5 && (echequier[mapiece.getX()+2][mapiece.getY()+1]==null || echequier[mapiece.getX()+2][mapiece.getY()+1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()+1);
			mapiece.malistex.add(mapiece.getX()+2);
		}
		//bas droite bas
		if(mapiece.getX()<=6 && mapiece.getY()<=4 && (echequier[mapiece.getX()+1][mapiece.getY()+2]==null || echequier[mapiece.getX()+1][mapiece.getY()+2].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()+2);
			mapiece.malistex.add(mapiece.getX()+1);
		}
		//bas gauche gauche
		if(mapiece.getX()>=2 && mapiece.getY()<=5 && (echequier[mapiece.getX()-2][mapiece.getY()+1]==null || echequier[mapiece.getX()-2][mapiece.getY()+1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()+1);
			mapiece.malistex.add(mapiece.getX()-2);
		}
		//bas gauche bas
		if(mapiece.getX()>=1 && mapiece.getY()<=4 && (echequier[mapiece.getX()-1][mapiece.getY()+2]==null || echequier[mapiece.getX()-1][mapiece.getY()+2].couleur!=mapiece.couleur)){
			mapiece.malistey.add(mapiece.getY()+2);
			mapiece.malistex.add(mapiece.getX()-1);
		}
		//haut gauche gauche
		if(mapiece.getX()>=2 && mapiece.getY()>=1 && (echequier[mapiece.getX()-2][mapiece.getY()-1]==null || echequier[mapiece.getX()-2][mapiece.getY()-1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-1);
			mapiece.malistex.add(mapiece.getX()-2);
		}
		//haut gauche haut
		if(mapiece.getX()>=1 && mapiece.getY()>=2 && (echequier[mapiece.getX()-1][mapiece.getY()-2]==null || echequier[mapiece.getX()-1][mapiece.getY()-2].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-2);
			mapiece.malistex.add(mapiece.getX()-1);
		}
		//haut droite droite
		if(mapiece.getX()<=5 && mapiece.getY()>=1 && (echequier[mapiece.getX()+2][mapiece.getY()-1]==null || echequier[mapiece.getX()+2][mapiece.getY()-1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-1);
			mapiece.malistex.add(mapiece.getX()+2);
		}
		//haut droite haut
		if(mapiece.getX()<=6 && mapiece.getY()>1 && (echequier[mapiece.getX()+1][mapiece.getY()-2]==null || echequier[mapiece.getX()+1][mapiece.getY()-2].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-2);
			mapiece.malistex.add(mapiece.getX()+1);
		}
	}
	
	protected void deplacementRoi(Piece mapiece, Piece[][] echequier) {
		if(mapiece.malistex!=null) {
			mapiece.malistex.clear();
			mapiece.malistey.clear();
		}
		//vers le haut
		if(mapiece.getY()>0 && (echequier[mapiece.getX()][mapiece.getY()-1]==null || echequier[mapiece.getX()][mapiece.getY()-1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-1);
			mapiece.malistex.add(mapiece.getX());
		}
		//vers le bas
		if(mapiece.getY()<6 && (echequier[mapiece.getX()][mapiece.getY()+1]==null || echequier[mapiece.getX()][mapiece.getY()+1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()+1);
			mapiece.malistex.add(mapiece.getX());
		}
		//vers la gauche
		if(mapiece.getX()>0 && (echequier[mapiece.getX()-1][mapiece.getY()]==null || echequier[mapiece.getX()-1][mapiece.getY()].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY());
			mapiece.malistex.add(mapiece.getX()-1);
		}
		//vers la droite
		if(mapiece.getX()<7 && (echequier[mapiece.getX()+1][mapiece.getY()]==null || echequier[mapiece.getX()+1][mapiece.getY()].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY());
			mapiece.malistex.add(mapiece.getX()+1);
		}
		//haut droite
		if(mapiece.getY()>0 && mapiece.getX()<7 && (echequier[mapiece.getX()+1][mapiece.getY()-1]==null || echequier[mapiece.getX()+1][mapiece.getY()-1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-1);
			mapiece.malistex.add(mapiece.getX()+1);
		}
		//vers le bas droite
		if(mapiece.getX()<7 && mapiece.getY()<6 && (echequier[mapiece.getX()+1][mapiece.getY()+1]==null || echequier[mapiece.getX()+1][mapiece.getY()+1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()+1);
			mapiece.malistex.add(mapiece.getX()+1);
		}
		//vers le bas gauche
		if(mapiece.getX()>0 && mapiece.getY()<6 && (echequier[mapiece.getX()-1][mapiece.getY()+1]==null || echequier[mapiece.getX()-1][mapiece.getY()+1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()+1);
			mapiece.malistex.add(mapiece.getX()-1);
		}
		//haut gauche
		if(mapiece.getX()>0 && mapiece.getY()>0 && (echequier[mapiece.getX()-1][mapiece.getY()-1]==null || echequier[mapiece.getX()-1][mapiece.getY()-1].couleur!=mapiece.couleur)) {
			mapiece.malistey.add(mapiece.getY()-1);
			mapiece.malistex.add(mapiece.getX()-1);
		}
	}

}

