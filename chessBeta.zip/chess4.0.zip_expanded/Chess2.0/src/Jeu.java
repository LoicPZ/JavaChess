public class Jeu implements Runnable {
	View vue;
	Model model;
	Controller controller;
	
	public Jeu(){
		model = new Model();
		
		this.controller = new Controller(model);
		
		this.vue = new View(model,this.controller);
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // ouverture d'un flux sur un fichier
		
		new Jeu();
		
	}

	// pour les thread
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
