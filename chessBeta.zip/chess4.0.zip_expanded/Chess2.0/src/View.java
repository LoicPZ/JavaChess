import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class View extends JFrame{
	Model model;
	
	//constructeur qui cr�er l'�ch�quier
	public View(Model p, Controller c){
		//cr�ation fen�tre
		this.setSize(900, 700);
		this.setTitle("Chess");
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.model=p;
		model.mesboutons = new JButton[8][7];
		//quadrillage fen�tre
		JPanel pn = new JPanel();
		
		
		pn.setPreferredSize(new Dimension(800,700));
		pn.setLayout(new GridLayout(7,8));
		//possage des pi�ces
		boolean blanc=false;
		for (int y=0; y<7; y++) 
		{
			for(int x=0; x<8; x++) 
			{
				JButton square = new JButton();
				model.mesboutons[x][y]=square;
				square.setPreferredSize(new Dimension(100,100));
				//place les pi�ces
				if(model.echequier[x][y] != null){
                    Image img = model.echequier[x][y].getImage();
                    square.setIcon(new ImageIcon(img));
                }
					
				//Alterne les couleurs pour faire un "damier"
				if(blanc) 
				{
					square.setBackground(new Color(255,255,255));
				}
				else 
				{
					square.setBackground(new Color(50,50,50));
				}
				square.addActionListener(c);
				pn.add(square);
				blanc=!blanc;
			}
			blanc=!blanc;
		}
	
		this.add(pn);
		this.setDefaultCloseOperation(3);
		this.setContentPane(pn);
		this.setVisible(true);
	}

	public void refresh(int x, int y){
		model.caseAvant.setIcon(new ImageIcon(model.echequier[x][y].getImage()));
	}
}